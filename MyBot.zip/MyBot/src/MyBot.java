import java.io.IOException;
import java.util.Arrays;


import org.jibble.pircbot.*;

import twitter4j.TwitterException;

public class MyBot extends PircBot
{
    public MyBot() 
    {
        this.setName("QuoteBotLad");
    }
    protected void onConnect()
    {
    	sendMessage("#MyChannel", " Welcome to My PircBot program! QuoteBotLad responds to these "
    			+ "keywords: Help: Brings up the list of commands. Time: Gives the current time. Get Weather: Gives the "
    			+ "weather for the zip-code or city specified; please make sure that if a city name contains more than one word, that you "
    			+ "don't put a space. Get Trends: gets the top ten trending items in the US Twitter. "
    			+ "If you need to see any of these commands again, please type 'help'.");
    }
    public void onMessage(String channel, String sender,
                       String login, String hostname, String message) 
    {
    	
    	String messageArr[] = message.split(" "); //Split message into individual words
    	
    	for(int x = 0; x < messageArr.length; x++) //Turn all words lower case for easier
    	{										   //Processing
    		messageArr[x] = messageArr[x].toLowerCase();
    	}
    	boolean command = Arrays.asList(messageArr) //If contains
    						.contains(("get")); 	//a get request
    												//enter loop
    	boolean qMark = messageArr[messageArr.length-1].endsWith("?");
    	if(command || qMark)
    	{
	    	for(int i = 0; i < messageArr.length; i++)
	    	{
	    		if(Arrays.asList(messageArr).contains(("weather")))
	    		{
	    				WeatherFetcher weatherBot = new WeatherFetcher();
	    				try
	    				{
	    					String regex = "\\d+";
	    					if(messageArr[i].matches(regex) && messageArr[i].length() == 5)
	    					{
	    						sendMessage(channel, sender + ": "+ weatherBot.startWebRequest(messageArr[i]));
	    					}
	    					else
	    					{
	    						sendMessage(channel,sender + ": " + weatherBot.startWebRequest(messageArr[messageArr.length-1]));
	    						break;
	    					}
	    				}
	    				catch(IOException e){sendMessage(channel, sender + "Error gathering data.");}
	    				break;
	    		}
	    	}
	    	if(Arrays.asList(messageArr).contains(("trend")) || Arrays.asList(messageArr).contains(("trends"))
	    	|| Arrays.asList(messageArr).contains(("trending")))
	    		{
	    				HashTagFetcher hashBot = new HashTagFetcher();
	    					try {sendMessage(channel, sender + " " + hashBot.getTrends());}
	    					catch (TwitterException e) 
	    					{
								e.printStackTrace();
								sendMessage(channel, sender + " Error gathering trends.");
							}
	    		}
    	}
    	else if(message.equalsIgnoreCase("time")) 
        {
            String time = new java.util.Date().toString();
            sendMessage(channel, sender + ": The time is now " + time);
        }
    	else if(message.equalsIgnoreCase("help"))
    	{
    		sendMessage(channel, sender + ": Welcome to My PircBot program! QuoteBotLad responds to these "
        			+ "keywords: Help: Brings up the list of commands. Time: Gives the current time. Get Weather: Gives the "
        			+ "weather for the zip-code or city specified; please make sure that if a city name contains more than one word, that you "
        			+ "put an underscore instead of a space. Get Trend(s/ing): gets the top ten trending items in the US Twitter. "
        			+ "If you need to see any of these commands again,");
    		sendMessage(channel, sender + " please type help.");
    	}
    	else
		{
			sendMessage(channel,sender + ": " + "Sorry, that input is out of my scope. To see my available commands, type 'help'");
		}
    		
    }
}