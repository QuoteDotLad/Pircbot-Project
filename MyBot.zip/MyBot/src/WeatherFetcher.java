import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonArray;


public class WeatherFetcher 
{
	
String startWebRequest(String city) throws IOException 
{
	
	String weatherURL = "http://api.openweathermap.org/data/2.5/weather?q=" + city + 
			",US&APPID=cfad66150788bc4047e40b829f6d86d2";
	StringBuilder result = new StringBuilder(); //Holds JSON response from server
	URL url = new URL(weatherURL);
	HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	
	conn.setRequestMethod("GET");
	BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	String line;
	while((line = rd.readLine()) != null)
	{
		result.append(line);
	}
	rd.close();
	parseJson(result.toString());
	return parseJson(result.toString());
}
static String parseJson(String json) //json is a string of json, gotten from the request
{
	DecimalFormat df = new DecimalFormat("#.00"); 
	JsonElement elem = new JsonParser().parse(json);
	JsonObject MasterWeatherObj = elem.getAsJsonObject(); //Break down with JSONEDITORONLINE
	
	//Gets city name
	JsonObject cityObj = MasterWeatherObj.getAsJsonObject();
	String cityName = cityObj.get("name").getAsString();
	
	JsonObject tempObj = MasterWeatherObj.getAsJsonObject("main");
	double temp = tempObj.get("temp").getAsDouble();
	temp = temp * 9/5 - 459.67;
	double tempMin = tempObj.get("temp_min").getAsDouble();
	tempMin = tempMin * 9/5 - 459.67;
	double tempMax = tempObj.get("temp_max").getAsDouble();
	tempMax = tempMax * 9/5 - 459.67;
	
	JsonArray jArrayWeather = (JsonArray) MasterWeatherObj.get("weather");
	JsonObject currentObj = (JsonObject) jArrayWeather.get(0);
	JsonElement main = currentObj.get("main");
	final String DEGREE = "\u00b0";
	if(main.getAsString().equalsIgnoreCase("Clouds"))
	{
		String weatherReturn = "The city " + cityName + " has a temperature of " + df.format(temp) 
		+ " " + DEGREE + "F, and the weather is currently Cloudy. The high is " + df.format(tempMax) 
		+ " " + DEGREE + "F, and the low is " + df.format(tempMin) + " " + DEGREE + "F.";
		return weatherReturn;
	}
	else if( main.getAsString().equalsIgnoreCase("Rain") || main.getAsString().equalsIgnoreCase("Snow") 
		  || main.getAsString().equalsIgnoreCase("Wind") || main.getAsString().equalsIgnoreCase("Mist"))
	{
		String weatherReturn = "The city " + cityName + " has a temperature of " + df.format(temp)
		+ " " + DEGREE + "F, and the weather is currently " + main.getAsString() + "y. The high is " + df.format(tempMax) 
		+ " " + DEGREE + "F, and the low is " + df.format(tempMin) + " " + DEGREE + "F.";
		return weatherReturn;
	}
	else
	{
		String weatherReturn = "The city " + cityName + " has a temperature of " + df.format(temp) 
		+ " " + DEGREE + "F, and the weather is currently " +  main.getAsString() + ". The high is " + df.format(tempMax) 
		+ " " + DEGREE + "F, and the low is " + df.format(tempMin) + " " + DEGREE + "F.";
			return weatherReturn;
	}
		
}
}
