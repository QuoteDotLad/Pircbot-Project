import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonArray;

public class HashTagFetcher 
{
	static String getTrends() throws TwitterException
	{
		String trendList = "";
		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true)
		  .setOAuthConsumerKey("Hpv4956P6gfo6kaG2dz5fbCNy")
		  .setOAuthConsumerSecret("KwO5vsvdp0pcuvOQsSZHXK2nh5Zjmx7VRHtqrVXKZvZ64zdJoJ")
		  .setOAuthAccessToken("2291332698-d2kfYdYOKE7RQ5s7KkfseLZIBbmXwWiG8HlFoWu")
		  .setOAuthAccessTokenSecret("x3zrCDo8eejNvqvvfBX3iHN0sEi04OLtqclkEbhvvNX8L");
		
		TwitterFactory tf = new TwitterFactory(cb.build());
		Twitter twitter = tf.getInstance();
		
			Integer idTrendLocation = getTrendLocationID("United States");
			
			  if (idTrendLocation == null) 
			  {
			        System.out.println("Trend Location Not Found");
			  }
			  Trends trends = twitter.getPlaceTrends(idTrendLocation);	        	
			        for (int i = 0; i < 10; i++)
			        {		
			        	trendList = trendList + "" + trends.getTrends()[i].getName() + ", ";
			        }
			        return trendList;
		}
	
	public static String GsonParse(String json)
	{
		
		JsonElement jelement = new JsonParser().parse(json);
	    JsonObject  jobject = jelement.getAsJsonObject();
	    jobject = jobject.getAsJsonObject("data");
	    JsonArray jarray = jobject.getAsJsonArray("trends");
	    jobject = jarray.get(0).getAsJsonObject();
	    String result = jobject.get("translatedText").toString();
	    return result;
	}
	private static Integer getTrendLocationID(String locationName)
	{
		int idTrendLocation = 0;
		try
		{
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			  .setOAuthConsumerKey("Hpv4956P6gfo6kaG2dz5fbCNy")
			  .setOAuthConsumerSecret("KwO5vsvdp0pcuvOQsSZHXK2nh5Zjmx7VRHtqrVXKZvZ64zdJoJ")
			  .setOAuthAccessToken("2291332698-d2kfYdYOKE7RQ5s7KkfseLZIBbmXwWiG8HlFoWu")
			  .setOAuthAccessTokenSecret("x3zrCDo8eejNvqvvfBX3iHN0sEi04OLtqclkEbhvvNX8L");
			
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();
			
			ResponseList<Location> locations;
			locations = twitter.getAvailableTrends();
			
			 for (Location location : locations) 
			 {
			        if(location.getName().toLowerCase().equals(locationName.toLowerCase())) 
			        {
			            idTrendLocation = location.getWoeid();
			            break;
			        }
			 }
			 if (idTrendLocation > 0) 
			 {
			 return idTrendLocation;
			 }
			 return null;

		} 
		catch(TwitterException te) 
		{
			        te.printStackTrace();
			        System.out.println("Failed to get trends: " + te.getMessage());
			        return null;
		}
	}
}
