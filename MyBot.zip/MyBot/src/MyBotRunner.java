public class MyBotRunner 
{
    
    public static void main(String[] args) throws Exception 
    {
        //Server we're connecting to and our credentials
    	String server = "irc.freenode.net";
        
        //Channel to join
        String channel = "#MyChannel";
        
        // Now start our bot up.
        MyBot bot = new MyBot();
        
        // Enable debugging output.
        bot.setVerbose(true);
        
        // Connect to the IRC server.
        bot.connect(server);

        // Join the #pircbot channel.
        bot.joinChannel(channel);
        
    }
    
}